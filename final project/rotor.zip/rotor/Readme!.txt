It's Airman from Megaman 2, remade in 3D by Neweegee using Misfit 3D Model. This also includes his Tornado shot and a Raccoon Leaf form for whatever reason.

Just give me some credit if you use it :3

